#include <Arduino.h>
#include <Wire.h> 
#include <LiquidCrystal_I2C.h>

// Set the LCD address to 0x27 for a 16 chars and 2 line display
LiquidCrystal_I2C lcd(0x27, 16, 2);
byte state =0;
byte sub_state=0;

void sub_multi(unsigned long sub_millis);
void sub_multi2(unsigned long sub_millis);
void process_single(unsigned long sub_millis_to_cal);
void process_single2(unsigned long sub_millis_to_cal);
String timer_single="";
String time_sub_multi="";
String time_sub_multi2="";
unsigned long m,sub_m,sub_m2,currentMillis,seconds,minutes,hours,time_count;
unsigned long sub_millis_stop=0;
unsigned long sub_current =0 ;
unsigned long start_current =0 ;

int select_multi=2;

void setup() {
  Serial.begin(115200);
  pinMode(D5,OUTPUT);
  pinMode(D6,OUTPUT);
  pinMode(D7,OUTPUT);
  pinMode(D3,INPUT);
  pinMode(D4,INPUT);
  digitalWrite(D5,LOW);
  digitalWrite(D6,LOW);
  digitalWrite(D7,LOW);
  // initialize the LCD
	lcd.begin();
	// Turn on the blacklight and print a message.
	lcd.backlight();
	lcd.print("Glenda");
  delay(1000);
  lcd.clear();
}
void loop() {
  if(state == 0 )
  {
    Serial.println("Now State 0 ");
    lcd.clear();
    lcd.setCursor(0,0);
    lcd.print("Select Mode");
    lcd.setCursor(0,1);
    lcd.print("1.Single 2.Duo");
    state = 1; 
  }
  if(state == 1)
  {
    Serial.println("Now State 1 ");
    int sw1 = digitalRead(D3);
    int sw2 = digitalRead(D4);
    digitalWrite(D5,LOW);
    digitalWrite(D6,LOW);
    digitalWrite(D7,HIGH);
    if(sw1 == 0)
    {
      while (digitalRead(D3)==0){
        delay(10);
      }
      state = 2;
    }
    if(sw2 == 0)
    {
      while (digitalRead(D4)==0){
        delay(10);
      }
      lcd.clear();
      state = 7;
    }
  }
  //---------------------------------Edit-7/2/2024-------------------------------
  if(state == 2 )
  {
    Serial.println("Now state 2 ");
    lcd.clear();
    lcd.setCursor(0,0);
    lcd.print("Sw1 = Start/Stop");
    lcd.setCursor(0,1);
    lcd.print("Sw2 = reset ");
    state =3;
  }
  if(state == 3)
  {
    Serial.println("Now state 3 ");
    int sw1 = digitalRead(D3);
    if(sw1 == 0)
    {
      while(digitalRead(D3)==0)
      {
        delay(10);
      }
      // m = millis();
      start_current = millis();
      digitalWrite(D5,HIGH);
      digitalWrite(D6,LOW);
      digitalWrite(D7,LOW);
      state =4;
    }
  }
  if(state == 4)
  {
    Serial.println("Now state 4 ");
    process_single(start_current);
  }
  if(state == 5)
  {
    digitalWrite(D5,LOW);
    digitalWrite(D6,HIGH);
    digitalWrite(D7,LOW);
    Serial.println("Now state 5 ");
    lcd.clear();
    lcd.setCursor(0,0);
    lcd.print(timer_single);
    lcd.setCursor(0,1);
    lcd.print("sw2 = reset");
    state =6;
  }
  if(state== 6)
  {
    Serial.println("Now State 6");
    Serial.println("Sub millis : "+String(sub_millis_stop));
    start_current = millis()-sub_current;

    int sw1 = digitalRead(D3);
    if(sw1 == 0)
    {
      while(digitalRead(D3)==0)
      {
        delay(10);
      }
      // m = millis();
      digitalWrite(D5,HIGH);
      digitalWrite(D6,LOW);
      digitalWrite(D7,LOW);
      state =4;
    }

    int sw2=digitalRead(D4);
    if(sw2 == 0)
    {
      while (digitalRead(D4)==0)
      {
        /* code */delay(10);
      }
      state = 0 ;

    }
  }
  //---------------------------End-Edit-7/2/2024-------------------------------

  if(state == 7)
  {
    Serial.println("Now state 7 ");
    lcd.clear();
    lcd.setCursor(0,1);
    lcd.print("sw2 Confirm");
      lcd.setCursor(0,0);
      lcd.print("select:"+String(select_multi)+"");
    state = 8;
  }
  if(state == 8)
  {
    Serial.println("Now State 8 ");

    int sw1 = digitalRead(D3);
    int sw2 = digitalRead(D4);

    if(sw1 == 0)
    {
      while (digitalRead(D3)==0){
        delay(10);
      }
      select_multi ++;
      if(select_multi > 2)select_multi=2;
      lcd.clear();
      lcd.setCursor(0,1);
      lcd.print("sw2 Confirm");
      lcd.setCursor(0,0);
      lcd.print("select:"+String(select_multi)+"");
    }
    if(sw2 == 0)
    {
      while (digitalRead(D4)==0){
        delay(10);
      }
      lcd.clear();
      state =9;
    }
  }
  if(state == 9 )
  {
    Serial.println("Now state 9");
    lcd.setCursor(0,0);
    lcd.print("sw2 start/stop");
    lcd.setCursor(0,1);
    lcd.print("sw2 push>timer");
    state =10;
  }
  if(state == 10)
  {
    int sw2 = digitalRead(D4);
    if(sw2 == 0)
    {
      while (digitalRead(D4)==0){
        delay(10);
      }
      m=millis();
      if(select_multi == 2)
      {
        m=millis();
        digitalWrite(D5,LOW);
        digitalWrite(D6,LOW);
        digitalWrite(D7,LOW);
        state = 11;
      }
    }
  }
  if(state == 11)
  {
    Serial.println("Now state 11");
    sub_multi(m);
  }
  if(state == 12)
  {
    Serial.println("Now state 12");
    sub_multi2(m);
  }
  if(state == 13)
  {
    Serial.println("Now state 13");
    lcd.clear();
    state = 14;
  }
  if(state == 14)
  {
    Serial.println("Now state 14");
    lcd.setCursor(0,0);
    lcd.print(time_sub_multi+" "+time_sub_multi2);
    lcd.setCursor(0,1);
    lcd.print(" sw2 for reset ");
    state =15;
  }
  if(state == 15)
  {
    Serial.println("Now state 15");
    int sw2 = digitalRead(D4);
    if(sw2 == 0)
    {
      while (digitalRead(D4)==0){
        delay(10);
      }
      digitalWrite(D5,LOW);
      digitalWrite(D6,LOW);
      digitalWrite(D7,LOW);
      state = 0;
      Serial.println("state = "+String(state));
    }
  }
}
void sub_multi(unsigned long sub_millis)
{
  unsigned long currentMillis = millis()-sub_millis;
  unsigned long seconds = currentMillis / 1000;
  unsigned long minutes = seconds / 60;

  currentMillis %= 1000;
  seconds %= 60;
  minutes %= 60;
  hours %= 24; 

  if (minutes < 10)
    Serial.print('0');
  Serial.print(minutes);
  Serial.print(':');
  if (seconds < 10)
    Serial.print('0');
  Serial.print(seconds);
  Serial.print('.');
  if (currentMillis < 100)
    Serial.print('0');
  if (currentMillis < 10)
    Serial.print('0');
  Serial.println(currentMillis);
  lcd.setCursor(0,0);
  lcd.print("                ");
  lcd.setCursor(0,1);
  lcd.print("                ");
  lcd.setCursor(0,0);
  lcd.print(String(minutes)+":"+String(seconds)+":"+String(currentMillis));

    int sw2 = digitalRead(D4);
    // int sw2 = digitalRead(D4);
    if(sw2 == 0)
    {
      while (digitalRead(D4)==0){
        delay(10);
      }
      // lcd.clear();
      time_sub_multi = String(minutes)+":"+String(seconds)+":"+String(currentMillis);
      digitalWrite(D5,HIGH);
      digitalWrite(D6,LOW);
      digitalWrite(D7,LOW);
      sub_m = millis();
      state = 12;
      Serial.println("state = "+String(state));
    }
}
void sub_multi2(unsigned long sub_millis)
{
  unsigned long currentMillis = millis()-sub_millis;
  unsigned long seconds = currentMillis / 1000;
  unsigned long minutes = seconds / 60;

  currentMillis %= 1000;
  seconds %= 60;
  minutes %= 60;
  hours %= 24; 

  if (minutes < 10)
    Serial.print('0');
  Serial.print(minutes);
  Serial.print(':');
  if (seconds < 10)
    Serial.print('0');
  Serial.print(seconds);
  Serial.print('.');
  if (currentMillis < 100)
    Serial.print('0');
  if (currentMillis < 10)
    Serial.print('0');
  Serial.println(currentMillis);
  lcd.setCursor(0,1);
  // lcd.print("                ");
  lcd.setCursor(0,1);
  lcd.print(String(minutes)+":"+String(seconds)+":"+String(currentMillis));

    int sw2 = digitalRead(D4);
    // int sw2 = digitalRead(D4);
    if(sw2 == 0)
    {
      while (digitalRead(D4)==0){
        delay(10);
      }
      // lcd.clear();
      time_sub_multi2 = String(minutes)+":"+String(seconds)+":"+String(currentMillis);
      digitalWrite(D5,HIGH);
        digitalWrite(D6,HIGH);
        digitalWrite(D7,LOW);
      state = 13;
      Serial.println("state = "+String(state));
    }
}
  //-------------------------------Edit-7/2/2024-------------------------------
void process_single(unsigned long sub_millis_to_cal)
{
  unsigned long currentMillis = millis()-sub_millis_to_cal;
  unsigned long seconds = currentMillis / 1000;
  unsigned long minutes = seconds / 60;
  sub_current = currentMillis;
  currentMillis %= 1000;
  seconds %= 60;
  minutes %= 60;
  hours %= 24; 

  if (minutes < 10)
    Serial.print('0');
  Serial.print(minutes);
  Serial.print(':');
  if (seconds < 10)
    Serial.print('0');
  Serial.print(seconds);
  Serial.print('.');
  if (currentMillis < 100)
    Serial.print('0');
  if (currentMillis < 10)
    Serial.print('0');
  Serial.println(currentMillis);
  lcd.setCursor(0,0);
  lcd.print("                ");
  lcd.setCursor(0,1);
  lcd.print("                ");
  lcd.setCursor(0,0);
  lcd.print(String(minutes)+":"+String(seconds)+":"+String(currentMillis));

    int sw1 = digitalRead(D3);
    // int sw2 = digitalRead(D4);
    if(sw1 == 0)
    {
      while (digitalRead(D3)==0){
        delay(10);
      }
      // lcd.clear();
      timer_single = String(minutes)+":"+String(seconds)+":"+String(currentMillis);
      sub_millis_stop = millis();
      state = 5;
      Serial.println("state = "+String(state));
    }
} 
//---------------------------End-Edit-7/2/2024-------------------------------